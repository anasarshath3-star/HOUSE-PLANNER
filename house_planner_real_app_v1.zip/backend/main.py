from fastapi import FastAPI
from pydantic import BaseModel

app = FastAPI(title="House Planner API")

DESIGNS = [
    {"id":1,"name":"Modern 2BHK","area":1000,"bedrooms":2,"style":"Modern","estimate":1900000},
    {"id":2,"name":"Family 2BHK","area":1200,"bedrooms":2,"style":"Contemporary","estimate":2300000},
    {"id":3,"name":"Premium 3BHK","area":1600,"bedrooms":3,"style":"Premium","estimate":3100000},
]
MATERIALS = [
    {"name":"Cement","category":"Core Material","note":"Compare grade, brand and local quotation"},
    {"name":"Steel","category":"Structure","note":"Final specification must be decided by an engineer"},
    {"name":"Bricks/Blocks","category":"Wall","note":"Compare thermal and cost properties"},
    {"name":"Tiles","category":"Interior","note":"Choose based on room use and budget"},
]

class PlanRequest(BaseModel):
    plot_area: float
    budget: float
    bedrooms: int
    style: str = "Modern"

@app.get("/")
def home():
    return {"status":"House Planner API running"}

@app.get("/designs")
def designs():
    return DESIGNS

@app.get("/materials")
def materials():
    return MATERIALS

@app.post("/plan")
def plan(req: PlanRequest):
    matches=[d for d in DESIGNS if d["bedrooms"]==req.bedrooms and d["estimate"]<=req.budget]
    if not matches:
        matches=[d for d in DESIGNS if d["bedrooms"]==req.bedrooms] or DESIGNS[:1]
    return {"input":req.model_dump(),"recommendations":matches[:3]}
