# House Planner Real App Prototype V1

This follows the requested house-building helper concept.

Flow:
Login/Register -> Home -> Plan My House -> Plot/Budget/Bedrooms/Style -> Recommendation -> Designs -> Design Details -> Floor Plan -> Budget -> Materials -> Interior -> Saved Designs -> Profile.

Mobile:
cd mobile
npm install
npx expo start

Backend:
cd backend
pip install -r requirements.txt
uvicorn main:app --reload

For phone testing, install Expo Go and scan the QR code. Keep phone and laptop on the same Wi-Fi.

Prototype estimates and floor plans are illustrative only. Final construction decisions should be checked by qualified professionals.
